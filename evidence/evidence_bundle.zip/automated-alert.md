﻿# Automated Dependency Scan Alert
Generated: 2025-10-24 17:29:00Z (UTC)
Source: CI pipeline local run -> npm audit --json
Detected vulnerabilities summary: 5 high, 0 critical.
Files attached: npm-audit.json, npm-deps.json, dependency-vulns.csv, dependency-scan-report.txt
Action created: Ticket SECURITY-AUDIT-1792
Assignee: security-team (redacted)
Notes: Please triage critical/high vulnerabilities first. See dependency-scan-report.txt for details and remediation guidance.
